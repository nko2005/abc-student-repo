export const credentials = {
  apiKey: "AIzaSyA4-JPsien7mQIf9Lv84h4E5ZiVTGDo_i4",
  authDomain: "kaleido-tower.firebaseapp.com",
  databaseURL: "https://kaleido-tower-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "kaleido-tower",
  storageBucket: "kaleido-tower.appspot.com",
  messagingSenderId: "541923412484",
  appId: "1:541923412484:web:b53bd977481521cfba0351"
};
